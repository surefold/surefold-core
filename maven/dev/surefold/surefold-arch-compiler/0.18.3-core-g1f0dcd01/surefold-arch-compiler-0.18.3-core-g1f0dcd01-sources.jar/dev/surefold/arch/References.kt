package dev.surefold.arch

import java.io.File
import org.jetbrains.kotlin.KtFakeSourceElementKind
import org.jetbrains.kotlin.KtSourceElement
import org.jetbrains.kotlin.diagnostics.DiagnosticReporter
import org.jetbrains.kotlin.diagnostics.reportOn
import org.jetbrains.kotlin.fir.FirElement
import org.jetbrains.kotlin.fir.analysis.checkers.MppCheckerKind
import org.jetbrains.kotlin.fir.analysis.checkers.context.CheckerContext
import org.jetbrains.kotlin.fir.analysis.checkers.declaration.FirDeclarationChecker
import org.jetbrains.kotlin.fir.declarations.FirFile
import org.jetbrains.kotlin.fir.declarations.FirRegularClass
import org.jetbrains.kotlin.fir.declarations.FirResolvedImport
import org.jetbrains.kotlin.fir.expressions.FirQualifiedAccessExpression
import org.jetbrains.kotlin.fir.expressions.FirResolvedQualifier
import org.jetbrains.kotlin.fir.references.toResolvedCallableSymbol
import org.jetbrains.kotlin.fir.symbols.impl.FirConstructorSymbol
import org.jetbrains.kotlin.fir.symbols.impl.FirLocalPropertySymbol
import org.jetbrains.kotlin.fir.symbols.impl.FirValueParameterSymbol
import org.jetbrains.kotlin.fir.types.ConeClassLikeType
import org.jetbrains.kotlin.fir.types.ConeKotlinType
import org.jetbrains.kotlin.fir.types.ConeKotlinTypeProjection
import org.jetbrains.kotlin.fir.types.FirResolvedTypeRef
import org.jetbrains.kotlin.fir.types.abbreviatedType
import org.jetbrains.kotlin.fir.types.lowerBoundIfFlexible
import org.jetbrains.kotlin.fir.visitors.FirVisitorVoid
import org.jetbrains.kotlin.name.ClassId

/**
 * Every reference in a file, by the symbol it resolved to, checked against every rule (spec 0315). One walk of the file
 * rather than a checker per kind of reference, so a file's whole verdict is known in one place.
 */
internal class ReferenceChecker(private val check: Check) : FirDeclarationChecker<FirFile>(MppCheckerKind.Common) {

    context(context: CheckerContext, reporter: DiagnosticReporter)
    override fun check(declaration: FirFile) {
        val walk = Walk(declaration.packageDirective.packageFqName.asString(), declaration.name)
        declaration.accept(walk)
        val path = declaration.pathFrom(check.root)
        val excused = { rule: Rule -> check.baseline?.excuses(path, rule.id) == true }
        val broken =
            walk.found
                .flatMap { found -> check.rules.filter { it.brokenBy(found.code, found.target) }.map { found to it } }
                // One error a place a rule: `b.Single.size` is the object and the property, both written from one `b`.
                .distinctBy { (found, rule) -> found.source.startOffset to rule.id }
        val where = check.baseline?.let { " in ${it.name}" }.orEmpty()
        broken
            .filterNot { (_, rule) -> excused(rule) }
            .forEach { (found, rule) ->
                reporter.reportOn(
                    found.source,
                    ArchDiagnostics.SUREFOLD_ARCH_FORBIDDEN,
                    "[${rule.id}] ${found.codeName} uses ${found.targetName}; ${rule.reason}. " +
                        "Fix the reference, or baseline it: '$path ${rule.id}'$where",
                    context,
                )
            }
        check.rules
            .filter { rule -> excused(rule) && broken.none { it.second == rule } }
            .forEach { rule ->
                reporter.reportOn(
                    declaration.packageDirective.source ?: declaration.source,
                    ArchDiagnostics.SUREFOLD_ARCH_STALE,
                    "[${rule.id}] $path no longer breaks this rule: delete its line from ${check.baseline?.name}",
                    context,
                )
            }
    }
}

/** The file's path from [root], as the baseline writes it, or its name where there is no root. */
private fun FirFile.pathFrom(root: File?): String {
    val file = sourceFile?.path?.let { File(it).canonicalFile }
    return file?.let { root?.let(file::relativeToOrNull) }?.invariantSeparatorsPath ?: name
}

/** One reference: where it is written, the code it is in, and what it refers to. */
private class Reference(
    val source: KtSourceElement,
    val code: Place,
    val codeName: String,
    val target: Place,
    val targetName: String,
)

private class Walk(private val packageName: String, private val fileName: String) : FirVisitorVoid() {
    val found = mutableListOf<Reference>()
    private var topLevelClass: String? = null

    override fun visitElement(element: FirElement) {
        if (element is FirRegularClass && topLevelClass == null && element.symbol.classId.outerClassId == null) {
            topLevelClass = element.symbol.classId.asSingleFqName().asString()
            element.acceptChildren(this)
            topLevelClass = null
            return
        }
        when (element) {
            is FirQualifiedAccessExpression -> access(element)
            is FirResolvedTypeRef -> type(element.source, element.coneType)
            is FirResolvedQualifier ->
                element.qualifierSymbol?.classId?.let { add(element.source, it.place(), it.fqName()) }
            is FirResolvedImport -> import(element)
        }
        element.acceptChildren(this)
    }

    /** A type as written, its arguments, and the alias it was written as, each a reference of its own. */
    private fun type(source: KtSourceElement?, type: ConeKotlinType) {
        val rigid = type.lowerBoundIfFlexible()
        (rigid as? ConeClassLikeType)?.lookupTag?.classId?.let { add(source, it.place(), it.fqName()) }
        rigid.abbreviatedType?.let { type(source, it) }
        rigid.typeArguments.forEach { argument ->
            (argument as? ConeKotlinTypeProjection)?.let { type(source, it.type) }
        }
    }

    /** An import names a package, a class in one, or a member of a class, whether or not anything uses it. */
    private fun import(import: FirResolvedImport) {
        val packageName = import.packageFqName.asString()
        val outermost = import.relativeParentClassName?.pathSegments()?.firstOrNull()?.let { "$packageName.$it" }
        val target =
            if (import.isAllUnder || import.relativeParentClassName != null || import.importedName == null) outermost
            else "$packageName.${import.importedName}"
        val name = if (import.isAllUnder) "${import.importedFqName}.*" else import.importedFqName.toString()
        add(import.source, Place(packageName, target), name)
    }

    private fun access(access: FirQualifiedAccessExpression) {
        val symbol = access.calleeReference.toResolvedCallableSymbol() ?: return
        if (symbol is FirLocalPropertySymbol || symbol is FirValueParameterSymbol) return
        val id = symbol.callableId ?: return
        val owner = id.classId
        val name =
            if (symbol is FirConstructorSymbol && owner != null) owner.fqName()
            else id.asFqNameForDebugInfo().asString()
        add(access.source, Place(id.packageName.asString(), owner?.outermost()), name)
    }

    private fun add(source: KtSourceElement?, target: Place, targetName: String) {
        // A fake source is code the compiler wrote, such as a loop's iterator() call: the real one is reported.
        if (source == null || source.kind is KtFakeSourceElementKind) return
        val code = Place(packageName, topLevelClass)
        found += Reference(source, code, topLevelClass ?: "$packageName ($fileName)", target, targetName)
    }
}

private fun ClassId.outermost(): String = outermostClassId.asSingleFqName().asString()

private fun ClassId.place(): Place = Place(packageFqName.asString(), outermost())

private fun ClassId.fqName(): String = asSingleFqName().asString()
